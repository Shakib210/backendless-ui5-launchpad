"use strict";

sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
  "use strict";

  /**
   * @namespace project1.controller
   */
  var App = Controller.extend("project1.controller.App", {
    onInit: function _onInit() {}
  });
  return App;
});