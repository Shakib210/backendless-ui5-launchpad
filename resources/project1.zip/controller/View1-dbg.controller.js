"use strict";

sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
  "use strict";

  /**
   * @namespace project1.controller
   */
  var View1 = Controller.extend("project1.controller.View1", {
    onInit: function _onInit() {}
  });
  return View1;
});