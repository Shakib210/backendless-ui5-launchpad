"use strict";

sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
  "use strict";

  /**
   * @namespace project2.controller
   */
  var App = Controller.extend("project2.controller.App", {
    onInit: function _onInit() {}
  });
  return App;
});