"use strict";

sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
  "use strict";

  /**
   * @namespace project2.controller
   */
  var View1 = Controller.extend("project2.controller.View1", {
    onInit: function _onInit() {}
  });
  return View1;
});