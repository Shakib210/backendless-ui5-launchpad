sap.ui.define(["project2/test/unit/controller/View1.controller"],function(){"use strict"});
//# sourceMappingURL=AllTests.js.map