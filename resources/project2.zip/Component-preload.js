//@ui5-bundle project2/Component-preload.js
sap.ui.require.preload({
	"project2/Component.js":function(){
"use strict";sap.ui.define(["sap/ui/core/UIComponent","./model/models"],function(e,t){"use strict";var i=t["createDeviceModel"];var n=e.extend("project2.Component",{metadata:{manifest:"json"},init:function t(){e.prototype.init.call(this);this.getRouter().initialize();this.setModel(i(),"device")}});return n});
},
	"project2/controller/App.controller.js":function(){
"use strict";sap.ui.define(["sap/ui/core/mvc/Controller"],function(t){"use strict";var e=t.extend("project2.controller.App",{onInit:function t(){}});return e});
},
	"project2/controller/View1.controller.js":function(){
"use strict";sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";var t=e.extend("project2.controller.View1",{onInit:function e(){}});return t});
},
	"project2/i18n/i18n.properties":'# This is the resource bundle for project2\n\n#Texts for manifest.json\n\n#XTIT: Application name\nappTitle=App Title\n\n#YDES: Application description\nappDescription=A Fiori application.\r\n#XTIT: Main view title\ntitle=App Title',
	"project2/manifest.json":'{"_version":"1.49.0","sap.app":{"id":"project2","type":"application","i18n":"i18n/i18n.properties","applicationVersion":{"version":"0.0.1"},"title":"{{appTitle}}","description":"{{appDescription}}","resources":"resources.json","sourceTemplate":{"id":"@sap/generator-fiori:basic","version":"1.10.5","toolsId":"7406e5d1-87db-4fe9-8050-81e184549cfd"},"crossNavigation":{"inbounds":{"project2-inbound":{"signature":{"parameters":{},"additionalParameters":"allowed"},"semanticObject":"project2","action":"display","title":"Project 2","subTitle":"","icon":"sap-icon://activities"}}}},"sap.ui":{"technology":"UI5","icons":{"icon":"","favIcon":"","phone":"","phone@2":"","tablet":"","tablet@2":""},"deviceTypes":{"desktop":true,"tablet":true,"phone":true}},"sap.ui5":{"flexEnabled":true,"dependencies":{"minUI5Version":"1.118.0","libs":{"sap.m":{},"sap.ui.core":{},"sap.f":{},"sap.suite.ui.generic.template":{},"sap.ui.comp":{},"sap.ui.generic.app":{},"sap.ui.table":{},"sap.ushell":{}}},"contentDensities":{"compact":true,"cozy":true},"models":{"i18n":{"type":"sap.ui.model.resource.ResourceModel","settings":{"bundleName":"project2.i18n.i18n"}}},"resources":{"css":[{"uri":"css/style.css"}]},"routing":{"config":{"routerClass":"sap.m.routing.Router","viewType":"XML","async":true,"viewPath":"project2.view","controlAggregation":"pages","controlId":"app","clearControlAggregation":false},"routes":[{"name":"RouteView1","pattern":":?query:","target":["TargetView1"]}],"targets":{"TargetView1":{"viewType":"XML","transition":"slide","clearControlAggregation":false,"viewId":"View1","viewName":"View1"}}},"rootView":{"viewName":"project2.view.App","type":"XML","async":true,"id":"App"}},"sap.cloud":{"public":true,"service":"sapDeploy"}}',
	"project2/model/models.js":function(){
"use strict";sap.ui.define(["sap/ui/model/json/JSONModel","sap/ui/Device"],function(e,i){"use strict";function n(){var n=new e(i);n.setDefaultBindingMode("OneWay");return n}var t={__esModule:true};t.createDeviceModel=n;return t});
},
	"project2/view/App.view.xml":'<mvc:View controllerName="project2.controller.App"\n    xmlns:html="http://www.w3.org/1999/xhtml"\n    xmlns:mvc="sap.ui.core.mvc" displayBlock="true"\n    xmlns="sap.m"><App id="app"></App></mvc:View>\n',
	"project2/view/View1.view.xml":'<mvc:View controllerName="project2.controller.View1"\n    xmlns:mvc="sap.ui.core.mvc" displayBlock="true"\n    xmlns="sap.m"><Page id="page" title="{i18n>title}"><content><Title id="_IDGenTitle1" text="my test app 2"></Title></content></Page></mvc:View>'
});
//# sourceMappingURL=Component-preload.js.map
